# EmanuelPaz.github.io
Emanuel Paz portfolio - Developer FrontEnd
Diseño Responsivo: Creo sitios web y aplicaciones que se ven y funcionan de manera óptima en dispositivos de todos los tamaños, desde smartphones hasta pantallas de escritorio de alta resolución.

HTML/CSS Avanzado: Domino el arte de la maquetación web con HTML y CSS modernos, asegurando una estructura sólida y estilos pulidos.
